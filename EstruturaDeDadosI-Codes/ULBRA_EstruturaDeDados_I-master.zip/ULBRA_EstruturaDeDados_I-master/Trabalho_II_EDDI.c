/*DESENVOLVEDOR: MARIO DE SOUZA ALVES NETO. */

#include <stdio.h>
#include <stdlib.h>

#define TAM 20

typedef struct original{
	int dados;
	struct original *prox;
}Original;

typedef struct par{
	int dados;
	struct par *prox;
}LSEPar;

typedef struct impar{
	int dados;
	struct impar *prox;
}LSEImpar;

int InsereNodo(Original **inicio,int v){
    Original *novo,*aux;
    novo=(Original *)malloc(sizeof(Original));

    if(novo!=NULL){
        novo->dados=v;
        novo->prox=NULL;
        if(*inicio==NULL) *inicio=novo;
        else{
            aux=*inicio;
            while(aux->prox!=NULL){
                aux=aux->prox;	
            }
            aux->prox=novo;
        }
    }
}

//Funçao para inserir valores a direita na lista
int InsereDireita(LSEPar **inicio,int v){
    LSEPar *novo,*aux;
    novo=(LSEPar *)malloc(sizeof(LSEPar));

    if(novo!=NULL){
        novo->dados=v;
        novo->prox=NULL;
        if(*inicio==NULL) *inicio=novo;
        else{
            aux=*inicio;
            while(aux->prox!=NULL){
                aux=aux->prox;	
            }
            aux->prox=novo;
        }
    }
}

//Função para inserir valores a esquerda na lista
int InsereEsquerda(LSEImpar ** inicio, int v){
	LSEImpar *novo = NULL;
	novo=(LSEImpar*) malloc(sizeof(LSEImpar));
	
	if(novo!=NULL){
            novo->dados = v;
            novo->prox=*inicio;
            *inicio=novo;
	}
} 

//Função para excluir todos os nodos com valor informado
int ExcluiValorLSEPAR(LSEPar **inicio, int excluiValor, int tam){
    LSEPar *aux = *inicio, *anterior = NULL, *del=aux->prox;

    while (auxAlt != NULL){
        if (del == inicio){
            if (del->dados == excluiValor){
                inicio = del;
                free(aux);
                aux = inicio;
                del = del->prox;
            }else{
                anterior = aux;
                aux = aux->prox;
                aux = aux->prox;
            }
        }else{
            if (aux->dados == excluiValor){
                anterior->prox = del;
                free(aux);
                aux = del;
                del = del->prox;
            }else{
                anterior = aux;
                aux = aux->prox;
                del = del->prox;
            }
        }
    }
    if (aux->dados == excluiValor){
        if (tam > 1){
            anterior->prox = NULL;
            free(aux);
        }else{
            free(aux);
            inicio = NULL;
        }
    }
}

//Função para excluir todos os nodos da LSE Impar
int ExcluiValorLSEIMPAR(LSEImpar **inicio){
	LSEImpar *aux = *inicio, *anterior, *del;
	int NodoExcluido = 0;
	
	if(inicio==NULL){
            printf("Lista vazia!\n");
            return 0;
	}else{
            while(aux != NULL){
                if(aux->dados % 3 == 0){
                    del = aux;
                    if(*inicio == aux){
                            *inicio = aux->prox;
                    }else{ 
                            anterior->prox = aux->prox;
                    }
                    aux = aux->prox;
                    free(del);
                    NodoExcluido ++;
                }else{ 
                    anterior = aux;
                    aux = aux->prox;
                }
            }
            return NodoExcluido;
	}
}

//Funcao imprime ORIGINAL
int ImprimeLSE(Original **inicio){
	Original *aux = *inicio;
	if(*inicio == NULL){
		printf("LV");
	}else{
		do{
			printf("%i\t", aux->dados);
			aux = aux -> prox;
		}while(aux != NULL);
	}
}

//Funcao imprime LSEPar
int ImprimeLSEPAR(LSEPar **inicio){
	LSEPar *aux = *inicio;
	if(*inicio == NULL){
		printf("LV");
	}else{
		do{
			printf("%i\t", aux->dados);
			aux = aux -> prox;
		}while(aux != NULL);
	}
}

//Funcao imprime LSEImpar
int ImprimeLSEIMPAR(LSEImpar **inicio){
	LSEImpar *aux = *inicio;
	if(*inicio == NULL){
		printf("LV");
	}else{
		do{
			printf("%i\t", aux->dados);
			aux = aux -> prox;
		}while(aux != NULL);
	}
}

int main(){
    Original *ptriOrigin = NULL;
    LSEPar *ptriPar = NULL;
    LSEImpar *ptriImpar = NULL;
    int valor, tamLsePar=0, NodosExcluidos=0, Verifica;
    int i, n;

    //Criação da LSE ORIGINAL
    for(i=0;i<TAM;i++){
            valor=rand()%100;
            InsereNodo(&ptriOrigin, valor);
            //Criação das LSE's par e impar  
            if(valor%2==0){
                    InsereDireita(&ptriPar, valor);
                    tamLsePar++;
            }else{
                    InsereEsquerda(&ptriImpar, valor);
            }
    }

    //Impressão da LSE ORIGINAL
    printf("--- Lista Simplesmente Encadeada ORIGINAL ---\n\n");
    ImprimeLSE(&ptriOrigin);

    //Impressão da LSE PAR e LSE IMPAR
    printf("\n\n--- Lista Simplesmente Encadeada PAR ---\n\n");
    ImprimeLSEPAR(&ptriPar);

    printf("\n\n--- Lista Simplesmente Encadeada IMPAR ---\n\n");
    ImprimeLSEIMPAR(&ptriImpar); 

    printf("\n\nDigite um valor para excluir da LSEPAR: ");
    scanf("%d", &n);
    Verifica = ExcluiValorLSEPAR(&ptriPar, n, tamLsePar); //Tamanho da lsepar por parametro
    if(Verifica == 0){
        printf("\nValor %d excluido da LSE PAR.", n);
    }else printf("\nSeu valor nao esta presente na LSE PAR.");
    
    printf("\n\n--- Lista Simplesmente Encadeada atualizada com Valores excluidos ---\n\n");
    ImprimeLSEPAR(&ptriPar); 

    printf("\n\n--- Lista Simplesmente Encadeada atualizada com Valores multiplos de 3 excluidos ---\n\n");
    NodosExcluidos = ExcluiValorLSEIMPAR(&ptriImpar);

    printf("Nodos excluidos da LSEIMPAR: %d\n\n", NodosExcluidos);
    ImprimeLSEIMPAR(&ptriImpar);

    printf("\n");
}