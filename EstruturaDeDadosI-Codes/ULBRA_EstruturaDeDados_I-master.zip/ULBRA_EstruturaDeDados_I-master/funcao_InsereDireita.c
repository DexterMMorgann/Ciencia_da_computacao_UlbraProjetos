#include <stdio.h>
#include <stdlib.h>

#define TAM 10

struct nodo{
	int dados;
	struct nodo * prox;
};

//Fun��o insere � direita
int InsereDireita(struct nodo **inicio, int v){
	struct nodo *novo, *aux;
	novo=(struct nodo *)malloc(sizeof(struct nodo));
	if(novo!=NULL){
		novo->dados = v;
		novo->prox = NULL;
		if(*inicio == NULL){
			*inicio = novo;
		}else{
			aux = *inicio;
			while(aux -> prox != NULL){
				aux = aux->prox;
			}
			aux -> prox = novo;
		}//fim do else
	}else printf("Nao foi possivel alocar!\n");
}//fim da fun��o

//Fun��o InsereEsquerda
int InsereEsquerda(struct nodo** inicio, int v){
	struct nodo *novo, *aux;
	novo=(struct nodo *)malloc(sizeof(struct nodo));
	*inicio = novo;
	else{
		printf("NFPA");
	}
	
}

//Funcao imprime
int imprimeELSE(struct nodo **inicio){
	struct nodo *aux = *inicio;
	if(*inicio == NULL){
		printf("LV");
	}else{
		do{
			printf("%i\t", aux->dados);
			aux = aux -> prox;
		}while(aux != NULL);
	}
}

//Fun��o principal
int main(){
	struct nodo *ptri = NULL;
	int valor, i;
	for(i=0; i< TAM; i++){
		valor = rand()%100;
		InsereDireita(&ptri, valor);
	}
	imprimeELSE(&ptri);
	
}
