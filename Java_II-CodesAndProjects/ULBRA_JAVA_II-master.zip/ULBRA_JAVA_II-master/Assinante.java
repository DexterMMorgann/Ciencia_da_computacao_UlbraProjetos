public class Assinante {
    String nome;
    String endereco;
    String cpf;
    Pacote pacoteCanal;

    public Assinante(String nome, String cpf) {
        this.nome = nome;
        this.cpf = cpf;
    }   
 
    public void setPacoteCanal(Pacote pacote){
        pacoteCanal = pacote;
        System.out.println("Pacote escolhido: "+pacote.getNomePacote());
    }
}