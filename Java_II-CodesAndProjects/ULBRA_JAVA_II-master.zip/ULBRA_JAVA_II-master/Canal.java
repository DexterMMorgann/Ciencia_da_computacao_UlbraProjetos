public class Canal implements IntCanal {
    private int NumeroCanal;
    private String NomeCanal;

    @Override
    public int getNumeroCanal() {
        return NumeroCanal;
    }

    @Override
    public void setNumeroCanal(int NumeroCanal) {
        this.NumeroCanal = NumeroCanal;
    }

    @Override
    public String getNomeCanal() {
        return NomeCanal;
    }

    @Override
    public void setNomeCanal(String NomeCanal) {
        this.NomeCanal = NomeCanal;
    }
}