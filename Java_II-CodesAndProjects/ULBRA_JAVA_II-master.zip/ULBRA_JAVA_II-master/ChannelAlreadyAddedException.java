public class ChannelAlreadyAddedException extends RuntimeException {

    public ChannelAlreadyAddedException() {
        System.out.println("Canal ja existe.");
    }
}