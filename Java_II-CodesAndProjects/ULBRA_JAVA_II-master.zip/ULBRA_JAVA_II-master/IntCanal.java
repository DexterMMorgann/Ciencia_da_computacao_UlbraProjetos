public interface IntCanal {
    public abstract void setNumeroCanal(int numeroCanal);
    public abstract int getNumeroCanal();
    public abstract void setNomeCanal(String nomeCanal);
    public abstract String getNomeCanal();
}

