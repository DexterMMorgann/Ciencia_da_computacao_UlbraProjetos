import java.util.ArrayList;

public class Pacote {
    private String nomePacote;
    ArrayList<Canal> colecaoCanais = new ArrayList();

    public void setNomePacote(String nomePacote){
        this.nomePacote = nomePacote;
    }    

     public String getNomePacote() {
        return nomePacote;
    }
    
    public void adicionaCanal(Canal canal){
        for (Canal colecaoCanai : colecaoCanais) {
            if(colecaoCanai.equals(canal)){
                throw new ChannelAlreadyAddedException();
            }
        }
        colecaoCanais.add(canal);
    }
    
    public void listaDadosPacote() {
        System.out.println(getNomePacote()+ "{");
        for(int i=0; i < colecaoCanais.size(); i++){
            System.out.println(colecaoCanais.get(i).getNomeCanal());
            System.out.println(colecaoCanais.get(i).getNumeroCanal());
        }
        System.out.println("}");
    }
}