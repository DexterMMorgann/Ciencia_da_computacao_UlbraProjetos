//DESENVOLVEDOR: Mario de Souza Alves Neto

#include <stdio.h>
#include <stdlib.h>

#define TAMVET 50
#define TAM 900

int Sorteia(int *vet){
	int i, contTam = 0;
	for(i=0; i<TAMVET; i++){
		vet[i] = rand()%TAM;
		contTam++;
	}
	Imprime(vet, contTam);
}

int VerificaPar(int *vet){
	int i, contPar=0, contTam = 0;
	int vetPar[TAMVET];
	
	for(i=0; i<TAMVET; i++){
		if((vet[i] % 2) == 0){
			vetPar[contPar++] = vet[i];
			contTam++;
		}
	}
	Imprime(vetPar, contTam);
}

int VerificaImpar(int *vet){
	int i, contImpar = 0, contTam = 0;
	int vetImpar[TAMVET]; 
	
	for(i=0; i<TAMVET; i++){
		if((vet[i] % 2) != 0){
			vetImpar[contImpar++] = vet[i];
			contTam++;
		}
	}
	Imprime(vetImpar, contTam);
}

int VerificaPrimo(int *vet){
	int i, j, contPrimo, contTam = 0;
	int vetPrimo[TAMVET]; 
	int contDivisor;
	
	for(i=0; i<TAMVET; i++){
		contDivisor = 0;
		if(vet[i] > 1){
			for(j=2; j<vet[i]; j++){
				if(vet[i] % j == 0){
					contDivisor++;
				}
			}
			if(contDivisor < 1){
				vetPrimo[contPrimo++] = vet[i];
				contTam++;
			}
		}
	}
	Imprime(vetPrimo, contTam);
}

int VerificaIntervalo(int *vet){
	int i, contIntervalo=0, contTam = 0;
	int vetIntervalo[TAMVET]; 
	
	for(i=0; i<TAMVET; i++){
		if(vet[i] >= 250 && vet[i] <= 650){
			vetIntervalo[contIntervalo++] = vet[i];
			contTam++;
		}
	}
	Imprime(vetIntervalo, contTam);
}

int Imprime(int *vet, int TamanhoDoVetor){
	int i, Linha, Coluna, contLinha=0;
	for(i=0; i<TamanhoDoVetor; i++){
		printf("%d \t", vet[i]);
		if(contLinha == 9){
			printf("\n");
			contLinha = 0;
			continue;
		}
		contLinha++;
	}
}

int main(){
	int vet[TAMVET];
	
	printf("Sorteio dos numeros:\n");
	printf("{\n");
	Sorteia(vet);
	printf("\n}\n");
	printf("===========================");
	
	printf("\nValores pares do vetor:\n");
	printf("{\n");
	VerificaPar(vet);
	printf("\n}\n");
	printf("===========================");
	
	printf("\nValores impares do vetor:\n");
	printf("{\n");
	VerificaImpar(vet);
	printf("\n}\n");
	printf("===========================");
	
	printf("\nValores primos do vetor:\n");
	printf("{\n");
	VerificaPrimo(vet);
	printf("\n}\n");
	printf("===========================");
	
	printf("\nValores intervalo do vetor:\n");
	printf("{\n");
	VerificaIntervalo(vet);
	printf("\n}\n");
	printf("===========================");
	
}
