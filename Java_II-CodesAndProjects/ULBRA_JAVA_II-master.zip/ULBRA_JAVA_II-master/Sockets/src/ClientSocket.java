
import java.net.*;
import java.io.*;
import java.util.*;
import java.net.Socket;

public class ClientSocket {
    public static void main(String args[]){
        try{
            //Conecta no servidor;
            Socket s = new Socket("www.ulbra.com.br", 80);
            //Busca Stream de E/S
            Scanner entrada = new Scanner(new InputStreamReader(s.getInputStream()));
            PrintWriter saida = new PrintWriter(s.getOutputStream());
            //Envia dados através do Stream
            saida.println("GET / HTTP/1.1\nHost: www.ulbra.com.br\n");
            saida.flush();
            //Imprime informação
            String dados = "papo";
            while((dados = entrada.nextLine()) != null){
                System.out.println(dados);
            }
            //Encerra recursos
            entrada.close();
            saida.close();
            s.close();
        }catch(UnknownHostException ex){
            System.out.println("Host desconhecido.\n");
        }catch(IOException ex){
            System.out.println("Erro na conexão: "+ex.getMessage());
        }
    }
}
