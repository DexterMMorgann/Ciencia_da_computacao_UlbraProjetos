import java.io.*;
import java.net.*;
import java.util.Scanner;

public class ServidorSocket {
    public static void main(String args[]){
        
        try{
            //instancia servidor
            ServerSocket server = new ServerSocket(8080);
            //conecta ao servidor
            Socket s = server.accept();
            //Busca Streams de Entrada E/S
            Scanner entrada = new Scanner(new InputStreamReader(s.getInputStream()));
            PrintWriter saida = new PrintWriter(s.getOutputStream());
            //Imprime requisição, informações
            String dados = "PEPO";
            while((dados = entrada.nextLine()) != null){
                if(dados.length() == 0){
                    break;
                }
                System.out.println(dados);
            }
            //Envia dados através do stream
            System.out.println("Recebi requisição!\n");
            saida.flush();
            //Encerra recursos
            entrada.close();
            saida.close();
            s.close();
        }catch(UnknownHostException ex){
            System.out.println("Servidor desconhecido.\n");
        }catch(IOException ex){
            System.out.println("Erro na conexão: "+ex.getMessage());
        }
    }
}
