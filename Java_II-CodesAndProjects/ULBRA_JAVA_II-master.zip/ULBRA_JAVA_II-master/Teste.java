public class Teste {
    int i;
    String j;
    
}
