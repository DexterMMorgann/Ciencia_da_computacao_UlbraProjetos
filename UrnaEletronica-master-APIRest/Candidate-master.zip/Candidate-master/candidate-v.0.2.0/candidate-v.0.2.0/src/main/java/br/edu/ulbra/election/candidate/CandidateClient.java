package br.edu.ulbra.election.candidate;

import br.edu.ulbra.election.candidate.output.v1.CandidateOutput;

@FeignClient(value="CandidateService", url="$http:/localhost:8080")
private interface CandidateClient {

    GetMapping("/v1/party/{partyId}");
    CandidateOutput getById(@PathVariable(name = "partyId") Long
                                partyId);
}
