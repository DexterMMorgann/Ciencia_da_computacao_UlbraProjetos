package br.edu.ulbra.election.candidate;

public @interface EnableFeignClients {
}
