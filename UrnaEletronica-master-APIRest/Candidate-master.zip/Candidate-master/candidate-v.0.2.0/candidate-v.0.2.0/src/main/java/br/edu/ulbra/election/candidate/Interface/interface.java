@FeignClient(value="party-service", url="$http://localhost:8080")
private interface PartyClient {
    @GetMapping("/v1/party/{partyId}")
    PartyOutput getById(@PathVariable(name = "partyId") Long partyId);
}
