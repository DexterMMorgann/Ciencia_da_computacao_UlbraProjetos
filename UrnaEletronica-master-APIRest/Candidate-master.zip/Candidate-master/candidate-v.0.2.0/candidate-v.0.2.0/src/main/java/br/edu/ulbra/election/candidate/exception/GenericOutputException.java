package br.edu.ulbra.election.candidate.exception;

public class GenericOutputException extends RuntimeException {

    public GenericOutputException(String message){
        super(message);
    }
}
