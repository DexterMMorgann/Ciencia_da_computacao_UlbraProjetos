package br.edu.ulbra.election.candidate.service;

public class FeignException {
}
