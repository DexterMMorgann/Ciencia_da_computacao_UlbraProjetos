alter table candidate alter column number rename to number_election;
