package br.edu.ulbra.election.election.enums;

public enum StateCodes {
    AC,
    AL,
    AP,
    AM,
    BA,
    CE,
    DF,
    ES,
    GO,
    MA,
    MT,
    MS,
    MG,
    PA,
    PB,
    PR,
    PE,
    PI,
    RO,
    RR,
    RS,
    RJ,
    RN,
    SC,
    SP,
    SE,
    TO;

}
