package br.edu.ulbra.election.election.exception;

public class GenericOutputException extends RuntimeException {

    public GenericOutputException(String message){
        super(message);
    }
}
