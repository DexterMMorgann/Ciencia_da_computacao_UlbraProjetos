package br.edu.ulbra.election.election.model;

//import br.edu.ulbra.election.election.output.v1.PartyOutput;

import javax.persistence.*;

@Entity
public class Candidate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private Long numberElection;

    //@Column(nullable = false)
    //private PartyOutput partyOutput;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getNumberElection() {
        return numberElection;
    }

    public void setNumberElection(Long numberElection) {
        this.numberElection = numberElection;
    }
    /*
    public PartyOutput getPartyOutput() {
        return partyOutput;
    }

    public void setPartyOutput(partyOutPut) {
        this.partyOutput = partyOutput;
    }*/
}
