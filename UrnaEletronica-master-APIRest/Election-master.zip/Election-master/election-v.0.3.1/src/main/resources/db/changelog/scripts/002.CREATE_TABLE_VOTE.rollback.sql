drop table vote;
