package br.edu.ulbra.election.party.exception;

public class GenericOutputException extends RuntimeException {

    public GenericOutputException(String message){
        super(message);
    }
}
