package br.edu.ulbra.election.voter.exception;

public class GenericOutputException extends RuntimeException {

    public GenericOutputException(String message){
        super(message);
    }
}
