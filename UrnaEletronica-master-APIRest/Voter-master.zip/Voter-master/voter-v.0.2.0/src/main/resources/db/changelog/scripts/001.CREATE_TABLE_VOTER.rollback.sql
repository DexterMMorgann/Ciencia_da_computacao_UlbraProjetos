drop table voter;
