package br.edu.ulbra.election.voter;

import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.ComponentScan;

@TestConfiguration
@ComponentScan(basePackages = {"br.edu.ulbra.election.voter"})
public class TestConfig {

}
